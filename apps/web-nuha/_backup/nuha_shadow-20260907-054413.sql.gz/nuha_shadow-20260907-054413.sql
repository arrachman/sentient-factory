-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: nuha_shadow
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nuha_shadow`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nuha_shadow` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `nuha_shadow`;

--
-- Table structure for table `agenda`
--

DROP TABLE IF EXISTS `agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tgl` date NOT NULL,
  `jam` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `judul` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agenda_tgl_idx` (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda`
--

LOCK TABLES `agenda` WRITE;
/*!40000 ALTER TABLE `agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `antrean_notifikasi`
--

DROP TABLE IF EXISTS `antrean_notifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `antrean_notifikasi` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kode_template` varchar(32) NOT NULL,
  `tujuan_id` varchar(64) NOT NULL,
  `tanggal_jadwal` date NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'Terkirim',
  `log_wa_id` bigint DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `antrean_notifikasi_kode_template_tujuan_id_tanggal_jadwal_key` (`kode_template`,`tujuan_id`,`tanggal_jadwal`),
  KEY `antrean_notifikasi_tanggal_jadwal_idx` (`tanggal_jadwal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antrean_notifikasi`
--

LOCK TABLES `antrean_notifikasi` WRITE;
/*!40000 ALTER TABLE `antrean_notifikasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `antrean_notifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arsip_sk`
--

DROP TABLE IF EXISTS `arsip_sk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arsip_sk` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nomor` varchar(64) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `tgl` date NOT NULL,
  `jenis` varchar(64) NOT NULL,
  `pegawai_id` bigint DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `arsip_sk_jenis_idx` (`jenis`),
  KEY `arsip_sk_pegawai_id_fkey` (`pegawai_id`),
  CONSTRAINT `arsip_sk_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arsip_sk`
--

LOCK TABLES `arsip_sk` WRITE;
/*!40000 ALTER TABLE `arsip_sk` DISABLE KEYS */;
/*!40000 ALTER TABLE `arsip_sk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asrama`
--

DROP TABLE IF EXISTS `asrama`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asrama` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jk` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas` int NOT NULL DEFAULT '0',
  `musyrif` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `asrama_nama_key` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asrama`
--

LOCK TABLES `asrama` WRITE;
/*!40000 ALTER TABLE `asrama` DISABLE KEYS */;
/*!40000 ALTER TABLE `asrama` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `aksi` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entitas` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entitas_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ringkasan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `perubahan` json DEFAULT NULL,
  `aktor_id` bigint DEFAULT NULL,
  `aktor_nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'anonim',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `audit_log_waktu_idx` (`waktu`),
  KEY `audit_log_entitas_entitas_id_idx` (`entitas`,`entitas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_soal`
--

DROP TABLE IF EXISTS `bank_soal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_soal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapel` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topik` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `butir` int NOT NULL DEFAULT '0',
  `dipakai` int NOT NULL DEFAULT '0',
  `penulis` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bank_soal_kode_key` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_soal`
--

LOCK TABLES `bank_soal` WRITE;
/*!40000 ALTER TABLE `bank_soal` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_soal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `beban_jam`
--

DROP TABLE IF EXISTS `beban_jam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `beban_jam` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pegawai_id` bigint NOT NULL,
  `tahun_ajaran_id` int DEFAULT NULL,
  `mapel` varchar(160) DEFAULT NULL,
  `jumlah_jam` int DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `beban_jam_pegawai_id_idx` (`pegawai_id`),
  KEY `beban_jam_tahun_ajaran_id_fkey` (`tahun_ajaran_id`),
  CONSTRAINT `beban_jam_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `beban_jam_tahun_ajaran_id_fkey` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beban_jam`
--

LOCK TABLES `beban_jam` WRITE;
/*!40000 ALTER TABLE `beban_jam` DISABLE KEYS */;
/*!40000 ALTER TABLE `beban_jam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `berkas_pendaftar`
--

DROP TABLE IF EXISTS `berkas_pendaftar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `berkas_pendaftar` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pendaftar_id` bigint NOT NULL,
  `nama` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wajib` tinyint(1) NOT NULL DEFAULT '1',
  `terverifikasi` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `berkas_pendaftar_pendaftar_id_fkey` (`pendaftar_id`),
  CONSTRAINT `berkas_pendaftar_pendaftar_id_fkey` FOREIGN KEY (`pendaftar_id`) REFERENCES `pendaftar` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `berkas_pendaftar`
--

LOCK TABLES `berkas_pendaftar` WRITE;
/*!40000 ALTER TABLE `berkas_pendaftar` DISABLE KEYS */;
/*!40000 ALTER TABLE `berkas_pendaftar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `butir_paket`
--

DROP TABLE IF EXISTS `butir_paket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `butir_paket` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `paket_id` int NOT NULL,
  `soal_id` bigint NOT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  `bobot` decimal(6,2) NOT NULL DEFAULT '1.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `butir_paket_paket_id_soal_id_key` (`paket_id`,`soal_id`),
  KEY `butir_paket_soal_id_fkey` (`soal_id`),
  CONSTRAINT `butir_paket_paket_id_fkey` FOREIGN KEY (`paket_id`) REFERENCES `paket_soal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `butir_paket_soal_id_fkey` FOREIGN KEY (`soal_id`) REFERENCES `soal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `butir_paket`
--

LOCK TABLES `butir_paket` WRITE;
/*!40000 ALTER TABLE `butir_paket` DISABLE KEYS */;
/*!40000 ALTER TABLE `butir_paket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capaian_pembelajaran`
--

DROP TABLE IF EXISTS `capaian_pembelajaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capaian_pembelajaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapel_id` int DEFAULT NULL,
  `mapel` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fase` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capaian` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `capaian_pembelajaran_kode_key` (`kode`),
  KEY `capaian_pembelajaran_mapel_id_fkey` (`mapel_id`),
  CONSTRAINT `capaian_pembelajaran_mapel_id_fkey` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capaian_pembelajaran`
--

LOCK TABLES `capaian_pembelajaran` WRITE;
/*!40000 ALTER TABLE `capaian_pembelajaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `capaian_pembelajaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `iso2` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso3` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numeric_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `countries_iso2_key` (`iso2`),
  UNIQUE KEY `countries_iso3_key` (`iso3`),
  KEY `countries_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foreign_addresses`
--

DROP TABLE IF EXISTS `foreign_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foreign_addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `person_id` bigint NOT NULL,
  `country_id` int NOT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_addresses_person_id_key` (`person_id`),
  KEY `foreign_addresses_country_id_idx` (`country_id`),
  CONSTRAINT `foreign_addresses_country_id_fkey` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `foreign_addresses_person_id_fkey` FOREIGN KEY (`person_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foreign_addresses`
--

LOCK TABLES `foreign_addresses` WRITE;
/*!40000 ALTER TABLE `foreign_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `foreign_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hafalan`
--

DROP TABLE IF EXISTS `hafalan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hafalan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `surat` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ayat` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nilai` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penguji` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hafalan_santri_id_tgl_idx` (`santri_id`,`tgl`),
  CONSTRAINT `hafalan_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hafalan`
--

LOCK TABLES `hafalan` WRITE;
/*!40000 ALTER TABLE `hafalan` DISABLE KEYS */;
/*!40000 ALTER TABLE `hafalan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `halaqah`
--

DROP TABLE IF EXISTS `halaqah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `halaqah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ustadz` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `waktu` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenjang` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anggota` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `halaqah`
--

LOCK TABLES `halaqah` WRITE;
/*!40000 ALTER TABLE `halaqah` DISABLE KEYS */;
/*!40000 ALTER TABLE `halaqah` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `izin`
--

DROP TABLE IF EXISTS `izin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `izin` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `santri_id` bigint NOT NULL,
  `jenis` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alasan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penjemput` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keluar_at` datetime(3) NOT NULL,
  `kembali_at` datetime(3) DEFAULT NULL,
  `status` enum('Menunggu','Disetujui','Ditolak','Selesai') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Menunggu',
  PRIMARY KEY (`id`),
  UNIQUE KEY `izin_kode_key` (`kode`),
  KEY `izin_status_idx` (`status`),
  KEY `izin_santri_id_fkey` (`santri_id`),
  CONSTRAINT `izin_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `izin`
--

LOCK TABLES `izin` WRITE;
/*!40000 ALTER TABLE `izin` DISABLE KEYS */;
/*!40000 ALTER TABLE `izin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jabatan_struktural`
--

DROP TABLE IF EXISTS `jabatan_struktural`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jabatan_struktural` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sk_nomor` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  `jabatan` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lingkup` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `divisi` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `periode_mulai` date NOT NULL,
  `periode_selesai` date NOT NULL,
  `pegawai_id` bigint DEFAULT NULL,
  `nama_mentah` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jabatan_struktural_sk_nomor_urutan_key` (`sk_nomor`,`urutan`),
  KEY `jabatan_struktural_lingkup_idx` (`lingkup`),
  KEY `jabatan_struktural_pegawai_id_fkey` (`pegawai_id`),
  CONSTRAINT `jabatan_struktural_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jabatan_struktural`
--

LOCK TABLES `jabatan_struktural` WRITE;
/*!40000 ALTER TABLE `jabatan_struktural` DISABLE KEYS */;
/*!40000 ALTER TABLE `jabatan_struktural` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_diniyah`
--

DROP TABLE IF EXISTS `jadwal_diniyah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_diniyah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hari` varchar(16) NOT NULL,
  `jenjang` varchar(32) NOT NULL,
  `kitab` varchar(160) NOT NULL,
  `ustadz` varchar(160) NOT NULL,
  `tempat` varchar(120) NOT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_diniyah`
--

LOCK TABLES `jadwal_diniyah` WRITE;
/*!40000 ALTER TABLE `jadwal_diniyah` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_diniyah` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_notifikasi`
--

DROP TABLE IF EXISTS `jadwal_notifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_notifikasi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode_template` varchar(32) NOT NULL,
  `cron` varchar(32) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `terakhir_jalan` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jadwal_notifikasi_kode_template_key` (`kode_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_notifikasi`
--

LOCK TABLES `jadwal_notifikasi` WRITE;
/*!40000 ALTER TABLE `jadwal_notifikasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_notifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_pelajaran`
--

DROP TABLE IF EXISTS `jadwal_pelajaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_pelajaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hari` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jam_ke` int NOT NULL,
  `waktu` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapel` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guru` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kelas` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruang` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `pegawai_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jadwal_pelajaran_hari_jam_ke_kelas_key` (`hari`,`jam_ke`,`kelas`),
  KEY `jadwal_pelajaran_guru_idx` (`guru`),
  KEY `jadwal_pelajaran_unit_id_fkey` (`unit_id`),
  KEY `jadwal_pelajaran_pegawai_id_fkey` (`pegawai_id`),
  CONSTRAINT `jadwal_pelajaran_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `jadwal_pelajaran_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_pelajaran`
--

LOCK TABLES `jadwal_pelajaran` WRITE;
/*!40000 ALTER TABLE `jadwal_pelajaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_pelajaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_piket`
--

DROP TABLE IF EXISTS `jadwal_piket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_piket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hari` varchar(16) NOT NULL,
  `waktu_mulai` varchar(16) NOT NULL,
  `waktu_selesai` varchar(16) NOT NULL,
  `pegawai_id` bigint DEFAULT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jadwal_piket_hari_waktu_mulai_key` (`hari`,`waktu_mulai`),
  KEY `jadwal_piket_hari_idx` (`hari`),
  KEY `jadwal_piket_pegawai_id_fkey` (`pegawai_id`),
  CONSTRAINT `jadwal_piket_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_piket`
--

LOCK TABLES `jadwal_piket` WRITE;
/*!40000 ALTER TABLE `jadwal_piket` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_piket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_ujian`
--

DROP TABLE IF EXISTS `jadwal_ujian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_ujian` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ujian_id` int NOT NULL,
  `mapel_id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `tgl` date NOT NULL,
  `waktu` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `durasi` int NOT NULL DEFAULT '90',
  `ruang` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pengawas` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jadwal_ujian_ujian_id_mapel_id_kelas_id_key` (`ujian_id`,`mapel_id`,`kelas_id`),
  KEY `jadwal_ujian_mapel_id_fkey` (`mapel_id`),
  KEY `jadwal_ujian_kelas_id_fkey` (`kelas_id`),
  CONSTRAINT `jadwal_ujian_kelas_id_fkey` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ujian_mapel_id_fkey` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `jadwal_ujian_ujian_id_fkey` FOREIGN KEY (`ujian_id`) REFERENCES `ujian` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_ujian`
--

LOCK TABLES `jadwal_ujian` WRITE;
/*!40000 ALTER TABLE `jadwal_ujian` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_ujian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jawaban_peserta`
--

DROP TABLE IF EXISTS `jawaban_peserta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jawaban_peserta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peserta_id` bigint NOT NULL,
  `soal_id` bigint NOT NULL,
  `jawaban` text COLLATE utf8mb4_unicode_ci,
  `ragu` tinyint(1) NOT NULL DEFAULT '0',
  `benar` tinyint(1) DEFAULT NULL,
  `skor` decimal(6,2) NOT NULL DEFAULT '0.00',
  `dinilai_oleh` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jawaban_peserta_peserta_id_soal_id_key` (`peserta_id`,`soal_id`),
  KEY `jawaban_peserta_soal_id_fkey` (`soal_id`),
  CONSTRAINT `jawaban_peserta_peserta_id_fkey` FOREIGN KEY (`peserta_id`) REFERENCES `peserta_cbt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jawaban_peserta_soal_id_fkey` FOREIGN KEY (`soal_id`) REFERENCES `soal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jawaban_peserta`
--

LOCK TABLES `jawaban_peserta` WRITE;
/*!40000 ALTER TABLE `jawaban_peserta` DISABLE KEYS */;
/*!40000 ALTER TABLE `jawaban_peserta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jurnal_mengajar`
--

DROP TABLE IF EXISTS `jurnal_mengajar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jurnal_mengajar` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pegawai_id` bigint DEFAULT NULL,
  `jadwal_id` int DEFAULT NULL,
  `kelas` varchar(32) DEFAULT NULL,
  `tgl` date NOT NULL,
  `jam_ke` int DEFAULT NULL,
  `materi` varchar(255) DEFAULT NULL,
  `catatan` varchar(255) DEFAULT NULL,
  `jumlah_hadir` int DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `jurnal_mengajar_tgl_idx` (`tgl`),
  KEY `jurnal_mengajar_pegawai_id_tgl_idx` (`pegawai_id`,`tgl`),
  KEY `jurnal_mengajar_jadwal_id_fkey` (`jadwal_id`),
  CONSTRAINT `jurnal_mengajar_jadwal_id_fkey` FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_pelajaran` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `jurnal_mengajar_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jurnal_mengajar`
--

LOCK TABLES `jurnal_mengajar` WRITE;
/*!40000 ALTER TABLE `jurnal_mengajar` DISABLE KEYS */;
/*!40000 ALTER TABLE `jurnal_mengajar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kamar`
--

DROP TABLE IF EXISTS `kamar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kamar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asrama_id` int NOT NULL,
  `kode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapasitas` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kamar_asrama_id_kode_key` (`asrama_id`,`kode`),
  CONSTRAINT `kamar_asrama_id_fkey` FOREIGN KEY (`asrama_id`) REFERENCES `asrama` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kamar`
--

LOCK TABLES `kamar` WRITE;
/*!40000 ALTER TABLE `kamar` DISABLE KEYS */;
/*!40000 ALTER TABLE `kamar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kegiatan_harian`
--

DROP TABLE IF EXISTS `kegiatan_harian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kegiatan_harian` (
  `id` int NOT NULL AUTO_INCREMENT,
  `jam` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ket` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kegiatan_harian`
--

LOCK TABLES `kegiatan_harian` WRITE;
/*!40000 ALTER TABLE `kegiatan_harian` DISABLE KEYS */;
/*!40000 ALTER TABLE `kegiatan_harian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelas`
--

DROP TABLE IF EXISTS `kelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kelas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_id` int NOT NULL,
  `nama` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tingkat` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wali_kelas` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun_ajaran_id` int DEFAULT NULL,
  `wali_kelas_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kelas_unit_id_nama_tahun_ajaran_id_key` (`unit_id`,`nama`,`tahun_ajaran_id`),
  KEY `kelas_unit_id_idx` (`unit_id`),
  KEY `kelas_tahun_ajaran_id_fkey` (`tahun_ajaran_id`),
  KEY `kelas_wali_kelas_id_fkey` (`wali_kelas_id`),
  CONSTRAINT `kelas_tahun_ajaran_id_fkey` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `kelas_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `kelas_wali_kelas_id_fkey` FOREIGN KEY (`wali_kelas_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas`
--

LOCK TABLES `kelas` WRITE;
/*!40000 ALTER TABLE `kelas` DISABLE KEYS */;
/*!40000 ALTER TABLE `kelas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komponen_gaji`
--

DROP TABLE IF EXISTS `komponen_gaji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `komponen_gaji` (
  `pegawai_id` bigint NOT NULL,
  `pokok` decimal(14,2) NOT NULL DEFAULT '0.00',
  `tunj_jab` decimal(14,2) NOT NULL DEFAULT '0.00',
  `tunj_kel` decimal(14,2) NOT NULL DEFAULT '0.00',
  `jam_mengajar` int NOT NULL DEFAULT '0',
  `tarif_jam` decimal(14,2) NOT NULL DEFAULT '0.00',
  `transport` decimal(14,2) NOT NULL DEFAULT '0.00',
  `bpjs` decimal(14,2) NOT NULL DEFAULT '0.00',
  `koperasi` decimal(14,2) NOT NULL DEFAULT '0.00',
  `pph` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`pegawai_id`),
  CONSTRAINT `komponen_gaji_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komponen_gaji`
--

LOCK TABLES `komponen_gaji` WRITE;
/*!40000 ALTER TABLE `komponen_gaji` DISABLE KEYS */;
/*!40000 ALTER TABLE `komponen_gaji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kunjungan`
--

DROP TABLE IF EXISTS `kunjungan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kunjungan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `nama_wali` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hubungan` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl` date NOT NULL,
  `jam_masuk` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jam_keluar` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keperluan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Terjadwal',
  PRIMARY KEY (`id`),
  KEY `kunjungan_tgl_idx` (`tgl`),
  KEY `kunjungan_santri_id_fkey` (`santri_id`),
  CONSTRAINT `kunjungan_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kunjungan`
--

LOCK TABLES `kunjungan` WRITE;
/*!40000 ALTER TABLE `kunjungan` DISABLE KEYS */;
/*!40000 ALTER TABLE `kunjungan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kursus_lms`
--

DROP TABLE IF EXISTS `kursus_lms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kursus_lms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guru` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modul` int NOT NULL DEFAULT '0',
  `selesai` int NOT NULL DEFAULT '0',
  `tugas_aktif` int NOT NULL DEFAULT '0',
  `nilai` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kursus_lms_kode_key` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kursus_lms`
--

LOCK TABLES `kursus_lms` WRITE;
/*!40000 ALTER TABLE `kursus_lms` DISABLE KEYS */;
/*!40000 ALTER TABLE `kursus_lms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_kecurangan`
--

DROP TABLE IF EXISTS `log_kecurangan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_kecurangan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `peserta_id` bigint NOT NULL,
  `jenis` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `log_kecurangan_peserta_id_idx` (`peserta_id`),
  CONSTRAINT `log_kecurangan_peserta_id_fkey` FOREIGN KEY (`peserta_id`) REFERENCES `peserta_cbt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_kecurangan`
--

LOCK TABLES `log_kecurangan` WRITE;
/*!40000 ALTER TABLE `log_kecurangan` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_kecurangan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_wa`
--

DROP TABLE IF EXISTS `log_wa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_wa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` int DEFAULT NULL,
  `tujuan` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Terkirim',
  `waktu` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id` varchar(96) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_wa_waktu_idx` (`waktu`),
  KEY `log_wa_template_id_fkey` (`template_id`),
  CONSTRAINT `log_wa_template_id_fkey` FOREIGN KEY (`template_id`) REFERENCES `template_wa` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_wa`
--

LOCK TABLES `log_wa` WRITE;
/*!40000 ALTER TABLE `log_wa` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_wa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mata_pelajaran`
--

DROP TABLE IF EXISTS `mata_pelajaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mata_pelajaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jp` int NOT NULL DEFAULT '0',
  `kelompok` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guru` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kkm` int NOT NULL DEFAULT '75',
  `kurikulum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mata_pelajaran_kode_key` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mata_pelajaran`
--

LOCK TABLES `mata_pelajaran` WRITE;
/*!40000 ALTER TABLE `mata_pelajaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `mata_pelajaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materi_lms`
--

DROP TABLE IF EXISTS `materi_lms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materi_lms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kursus_id` int NOT NULL,
  `judul` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `materi_lms_kursus_id_fkey` (`kursus_id`),
  CONSTRAINT `materi_lms_kursus_id_fkey` FOREIGN KEY (`kursus_id`) REFERENCES `kursus_lms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materi_lms`
--

LOCK TABLES `materi_lms` WRITE;
/*!40000 ALTER TABLE `materi_lms` DISABLE KEYS */;
/*!40000 ALTER TABLE `materi_lms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urutan` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_peran`
--

DROP TABLE IF EXISTS `menu_peran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_peran` (
  `menu_id` int NOT NULL,
  `peran_id` int NOT NULL,
  PRIMARY KEY (`menu_id`,`peran_id`),
  KEY `menu_peran_peran_id_fkey` (`peran_id`),
  CONSTRAINT `menu_peran_menu_id_fkey` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_peran_peran_id_fkey` FOREIGN KEY (`peran_id`) REFERENCES `peran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_peran`
--

LOCK TABLES `menu_peran` WRITE;
/*!40000 ALTER TABLE `menu_peran` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_peran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nilai`
--

DROP TABLE IF EXISTS `nilai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nilai` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `mapel_id` int NOT NULL,
  `periode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tugas` decimal(5,2) NOT NULL DEFAULT '0.00',
  `uts` decimal(5,2) NOT NULL DEFAULT '0.00',
  `uas` decimal(5,2) NOT NULL DEFAULT '0.00',
  `akhir` decimal(5,2) NOT NULL DEFAULT '0.00',
  `predikat` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nilai_santri_id_mapel_id_periode_key` (`santri_id`,`mapel_id`,`periode`),
  KEY `nilai_mapel_id_fkey` (`mapel_id`),
  CONSTRAINT `nilai_mapel_id_fkey` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `nilai_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nilai`
--

LOCK TABLES `nilai` WRITE;
/*!40000 ALTER TABLE `nilai` DISABLE KEYS */;
/*!40000 ALTER TABLE `nilai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nilai_ujian`
--

DROP TABLE IF EXISTS `nilai_ujian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nilai_ujian` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `jadwal_id` int NOT NULL,
  `santri_id` bigint NOT NULL,
  `nilai` decimal(5,2) NOT NULL DEFAULT '0.00',
  `hadir` tinyint(1) NOT NULL DEFAULT '1',
  `catatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nilai_ujian_jadwal_id_santri_id_key` (`jadwal_id`,`santri_id`),
  KEY `nilai_ujian_santri_id_fkey` (`santri_id`),
  CONSTRAINT `nilai_ujian_jadwal_id_fkey` FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_ujian` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nilai_ujian_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nilai_ujian`
--

LOCK TABLES `nilai_ujian` WRITE;
/*!40000 ALTER TABLE `nilai_ujian` DISABLE KEYS */;
/*!40000 ALTER TABLE `nilai_ujian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obat`
--

DROP TABLE IF EXISTS `obat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `satuan` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stok` int NOT NULL DEFAULT '0',
  `stok_min` int NOT NULL DEFAULT '0',
  `kadaluarsa` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `obat_nama_key` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obat`
--

LOCK TABLES `obat` WRITE;
/*!40000 ALTER TABLE `obat` DISABLE KEYS */;
/*!40000 ALTER TABLE `obat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opsi_soal`
--

DROP TABLE IF EXISTS `opsi_soal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opsi_soal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `soal_id` bigint NOT NULL,
  `label` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `benar` tinyint(1) NOT NULL DEFAULT '0',
  `urutan` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `opsi_soal_soal_id_label_key` (`soal_id`,`label`),
  CONSTRAINT `opsi_soal_soal_id_fkey` FOREIGN KEY (`soal_id`) REFERENCES `soal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opsi_soal`
--

LOCK TABLES `opsi_soal` WRITE;
/*!40000 ALTER TABLE `opsi_soal` DISABLE KEYS */;
/*!40000 ALTER TABLE `opsi_soal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orang`
--

DROP TABLE IF EXISTS `orang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orang` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nik` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jk` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `tmp_lahir` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hp` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  `rt` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rw` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kelurahan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kecamatan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kabupaten` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_kk` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anak_ke` int DEFAULT NULL,
  `jumlah_saudara` int DEFAULT NULL,
  `hobi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cita_cita` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asal_sekolah` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan_terakhir` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gelar` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `panggilan` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desa_id` bigint DEFAULT NULL,
  `kode_pos` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orang_nik_key` (`nik`),
  UNIQUE KEY `orang_email_key` (`email`),
  KEY `orang_nama_idx` (`nama`),
  KEY `orang_desa_id_idx` (`desa_id`),
  CONSTRAINT `orang_desa_id_fkey` FOREIGN KEY (`desa_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orang`
--

LOCK TABLES `orang` WRITE;
/*!40000 ALTER TABLE `orang` DISABLE KEYS */;
/*!40000 ALTER TABLE `orang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paket_soal`
--

DROP TABLE IF EXISTS `paket_soal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paket_soal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapel_id` int NOT NULL,
  `jenis` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTS',
  `durasi` int NOT NULL DEFAULT '90',
  `acak_soal` tinyint(1) NOT NULL DEFAULT '1',
  `acak_opsi` tinyint(1) NOT NULL DEFAULT '1',
  `tampil_hasil` tinyint(1) NOT NULL DEFAULT '0',
  `kkm` int NOT NULL DEFAULT '75',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draf',
  `penulis` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `paket_soal_kode_key` (`kode`),
  KEY `paket_soal_status_idx` (`status`),
  KEY `paket_soal_mapel_id_fkey` (`mapel_id`),
  CONSTRAINT `paket_soal_mapel_id_fkey` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paket_soal`
--

LOCK TABLES `paket_soal` WRITE;
/*!40000 ALTER TABLE `paket_soal` DISABLE KEYS */;
/*!40000 ALTER TABLE `paket_soal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pegawai`
--

DROP TABLE IF EXISTS `pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pegawai` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `orang_id` bigint NOT NULL,
  `nip` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_id` int DEFAULT NULL,
  `jabatan` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rekening` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  `pendidikan_terakhir` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mapel_diampu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tugas_tambahan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jam_mengajar` int NOT NULL DEFAULT '0',
  `tmp_tgl_lahir` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pegawai_orang_id_key` (`orang_id`),
  UNIQUE KEY `pegawai_nip_key` (`nip`),
  KEY `pegawai_unit_id_fkey` (`unit_id`),
  CONSTRAINT `pegawai_orang_id_fkey` FOREIGN KEY (`orang_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pegawai_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pegawai`
--

LOCK TABLES `pegawai` WRITE;
/*!40000 ALTER TABLE `pegawai` DISABLE KEYS */;
/*!40000 ALTER TABLE `pegawai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pegawai_unit`
--

DROP TABLE IF EXISTS `pegawai_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pegawai_unit` (
  `pegawai_id` bigint NOT NULL,
  `unit_id` int NOT NULL,
  `jabatan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nip` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utama` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`pegawai_id`,`unit_id`),
  KEY `pegawai_unit_unit_id_idx` (`unit_id`),
  CONSTRAINT `pegawai_unit_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pegawai_unit_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pegawai_unit`
--

LOCK TABLES `pegawai_unit` WRITE;
/*!40000 ALTER TABLE `pegawai_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `pegawai_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembayaran`
--

DROP TABLE IF EXISTS `pembayaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayaran` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tagihan_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `metode` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pembayaran_tagihan_id_fkey` (`tagihan_id`),
  CONSTRAINT `pembayaran_tagihan_id_fkey` FOREIGN KEY (`tagihan_id`) REFERENCES `tagihan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran`
--

LOCK TABLES `pembayaran` WRITE;
/*!40000 ALTER TABLE `pembayaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `pembayaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pendaftar`
--

DROP TABLE IF EXISTS `pendaftar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pendaftar` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `no_reg` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jk` enum('L','P') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pilihan` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asal_sekolah` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hp_wali` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_daftar` date NOT NULL,
  `nilai` decimal(5,2) DEFAULT NULL,
  `status` enum('Baru','Verifikasi','Seleksi','Lulus','TidakLulus','DaftarUlang') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Baru',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `pendaftar_no_reg_key` (`no_reg`),
  KEY `pendaftar_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pendaftar`
--

LOCK TABLES `pendaftar` WRITE;
/*!40000 ALTER TABLE `pendaftar` DISABLE KEYS */;
/*!40000 ALTER TABLE `pendaftar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengumuman`
--

DROP TABLE IF EXISTS `pengumuman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengumuman` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tgl` date NOT NULL,
  `judul` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Semua',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `pengumuman_tgl_idx` (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengumuman`
--

LOCK TABLES `pengumuman` WRITE;
/*!40000 ALTER TABLE `pengumuman` DISABLE KEYS */;
/*!40000 ALTER TABLE `pengumuman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peran`
--

DROP TABLE IF EXISTS `peran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peran_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peran`
--

LOCK TABLES `peran` WRITE;
/*!40000 ALTER TABLE `peran` DISABLE KEYS */;
/*!40000 ALTER TABLE `peran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perangkat_ajar`
--

DROP TABLE IF EXISTS `perangkat_ajar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perangkat_ajar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapel` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kelas` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topik` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pertemuan` int NOT NULL DEFAULT '0',
  `guru` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draf',
  PRIMARY KEY (`id`),
  UNIQUE KEY `perangkat_ajar_kode_key` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perangkat_ajar`
--

LOCK TABLES `perangkat_ajar` WRITE;
/*!40000 ALTER TABLE `perangkat_ajar` DISABLE KEYS */;
/*!40000 ALTER TABLE `perangkat_ajar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peserta_cbt`
--

DROP TABLE IF EXISTS `peserta_cbt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peserta_cbt` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sesi_id` int NOT NULL,
  `santri_id` bigint NOT NULL,
  `no_peserta` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Belum','Mengerjakan','Selesai','Dibekukan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Belum',
  `mulai_at` datetime(3) DEFAULT NULL,
  `selesai_at` datetime(3) DEFAULT NULL,
  `urutan` text COLLATE utf8mb4_unicode_ci,
  `skor` decimal(6,2) NOT NULL DEFAULT '0.00',
  `benar` int NOT NULL DEFAULT '0',
  `salah` int NOT NULL DEFAULT '0',
  `kosong` int NOT NULL DEFAULT '0',
  `theta` decimal(6,3) DEFAULT NULL,
  `pelanggaran` int NOT NULL DEFAULT '0',
  `ip_terakhir` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `peserta_cbt_sesi_id_santri_id_key` (`sesi_id`,`santri_id`),
  KEY `peserta_cbt_status_idx` (`status`),
  KEY `peserta_cbt_santri_id_fkey` (`santri_id`),
  CONSTRAINT `peserta_cbt_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `peserta_cbt_sesi_id_fkey` FOREIGN KEY (`sesi_id`) REFERENCES `sesi_cbt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peserta_cbt`
--

LOCK TABLES `peserta_cbt` WRITE;
/*!40000 ALTER TABLE `peserta_cbt` DISABLE KEYS */;
/*!40000 ALTER TABLE `peserta_cbt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presensi`
--

DROP TABLE IF EXISTS `presensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presensi` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `sesi` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Hadir','Sakit','Izin','Alpa','Terlambat','PulangCepat') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Hadir',
  `ket` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `presensi_santri_id_tgl_sesi_key` (`santri_id`,`tgl`,`sesi`),
  CONSTRAINT `presensi_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presensi`
--

LOCK TABLES `presensi` WRITE;
/*!40000 ALTER TABLE `presensi` DISABLE KEYS */;
/*!40000 ALTER TABLE `presensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presensi_pegawai`
--

DROP TABLE IF EXISTS `presensi_pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presensi_pegawai` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pegawai_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `jam_masuk` varchar(16) DEFAULT NULL,
  `jam_pulang` varchar(16) DEFAULT NULL,
  `status` enum('Hadir','Sakit','Izin','Alpa','Terlambat','PulangCepat') NOT NULL DEFAULT 'Hadir',
  `ket` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `presensi_pegawai_pegawai_id_tgl_key` (`pegawai_id`,`tgl`),
  CONSTRAINT `presensi_pegawai_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presensi_pegawai`
--

LOCK TABLES `presensi_pegawai` WRITE;
/*!40000 ALTER TABLE `presensi_pegawai` DISABLE KEYS */;
/*!40000 ALTER TABLE `presensi_pegawai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profil_kesehatan`
--

DROP TABLE IF EXISTS `profil_kesehatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profil_kesehatan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `berat_kg` decimal(5,2) DEFAULT NULL,
  `tinggi_cm` decimal(5,2) DEFAULT NULL,
  `gol_darah` varchar(3) DEFAULT NULL,
  `riwayat_penyakit` varchar(255) DEFAULT NULL,
  `alergi` varchar(255) DEFAULT NULL,
  `kebutuhan_khusus` varchar(255) DEFAULT NULL,
  `catatan` text,
  `updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `profil_kesehatan_santri_id_key` (`santri_id`),
  CONSTRAINT `profil_kesehatan_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profil_kesehatan`
--

LOCK TABLES `profil_kesehatan` WRITE;
/*!40000 ALTER TABLE `profil_kesehatan` DISABLE KEYS */;
/*!40000 ALTER TABLE `profil_kesehatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profil_lembaga`
--

DROP TABLE IF EXISTS `profil_lembaga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profil_lembaga` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_arab` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `singkatan` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telepon` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun_berdiri` int DEFAULT NULL,
  `akta_notaris` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ketua_nama` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pengasuh_nama` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rekening` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visi` text COLLATE utf8mb4_unicode_ci,
  `misi` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  `desa_id` bigint DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profil_lembaga_key_key` (`key`),
  KEY `profil_lembaga_desa_id_idx` (`desa_id`),
  CONSTRAINT `profil_lembaga_desa_id_fkey` FOREIGN KEY (`desa_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profil_lembaga`
--

LOCK TABLES `profil_lembaga` WRITE;
/*!40000 ALTER TABLE `profil_lembaga` DISABLE KEYS */;
/*!40000 ALTER TABLE `profil_lembaga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_aliases`
--

DROP TABLE IF EXISTS `region_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `region_aliases` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `region_id` bigint NOT NULL,
  `alias` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('FormerName','AlternateSpelling','Abbreviation','LocalLanguage') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_aliases_region_id_alias_key` (`region_id`,`alias`),
  KEY `region_aliases_alias_idx` (`alias`),
  CONSTRAINT `region_aliases_region_id_fkey` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_aliases`
--

LOCK TABLES `region_aliases` WRITE;
/*!40000 ALTER TABLE `region_aliases` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_aliases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `country_id` int NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `level` enum('Province','City','District','Village') COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_label` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province_id` bigint DEFAULT NULL,
  `city_id` bigint DEFAULT NULL,
  `district_id` bigint DEFAULT NULL,
  `depth` int NOT NULL DEFAULT '1',
  `full_name` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `area_km2` decimal(12,4) DEFAULT NULL,
  `populasi` int DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `replaced_by_id` bigint DEFAULT NULL,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `regions_country_id_code_key` (`country_id`,`kode`),
  KEY `regions_parent_id_level_is_active_idx` (`parent_id`,`level`,`is_active`),
  KEY `regions_level_is_active_idx` (`level`,`is_active`),
  KEY `regions_province_id_city_id_district_id_idx` (`province_id`,`city_id`,`district_id`),
  KEY `regions_postal_code_idx` (`postal_code`),
  KEY `regions_city_id_fkey` (`city_id`),
  KEY `regions_district_id_fkey` (`district_id`),
  KEY `regions_replaced_by_id_fkey` (`replaced_by_id`),
  CONSTRAINT `regions_city_id_fkey` FOREIGN KEY (`city_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `regions_country_id_fkey` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `regions_district_id_fkey` FOREIGN KEY (`district_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `regions_parent_id_fkey` FOREIGN KEY (`parent_id`) REFERENCES `regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `regions_province_id_fkey` FOREIGN KEY (`province_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `regions_replaced_by_id_fkey` FOREIGN KEY (`replaced_by_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rekam_medis`
--

DROP TABLE IF EXISTS `rekam_medis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rekam_medis` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `jam` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keluhan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diagnosis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terapi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tindak_lanjut` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `petugas` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rekam_medis_santri_id_tgl_idx` (`santri_id`,`tgl`),
  CONSTRAINT `rekam_medis_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rekam_medis`
--

LOCK TABLES `rekam_medis` WRITE;
/*!40000 ALTER TABLE `rekam_medis` DISABLE KEYS */;
/*!40000 ALTER TABLE `rekam_medis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relasi_wali`
--

DROP TABLE IF EXISTS `relasi_wali`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relasi_wali` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `wali_id` bigint NOT NULL,
  `anak_id` bigint NOT NULL,
  `hubungan` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pekerjaan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utama` tinyint(1) NOT NULL DEFAULT '1',
  `nik` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ttl` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendapatan` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peran` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `relasi_wali_wali_id_anak_id_key` (`wali_id`,`anak_id`),
  KEY `relasi_wali_anak_id_fkey` (`anak_id`),
  CONSTRAINT `relasi_wali_anak_id_fkey` FOREIGN KEY (`anak_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relasi_wali_wali_id_fkey` FOREIGN KEY (`wali_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relasi_wali`
--

LOCK TABLES `relasi_wali` WRITE;
/*!40000 ALTER TABLE `relasi_wali` DISABLE KEYS */;
/*!40000 ALTER TABLE `relasi_wali` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riwayat_pendidikan`
--

DROP TABLE IF EXISTS `riwayat_pendidikan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `riwayat_pendidikan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `orang_id` bigint NOT NULL,
  `unit_id` int NOT NULL,
  `kelas_nama` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tingkat` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun_ajaran_id` int NOT NULL,
  `status` enum('Mukim','Alumni','Keluar') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Alumni',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `riwayat_pendidikan_orang_id_unit_id_tahun_ajaran_id_key` (`orang_id`,`unit_id`,`tahun_ajaran_id`),
  KEY `riwayat_pendidikan_unit_id_fkey` (`unit_id`),
  KEY `riwayat_pendidikan_tahun_ajaran_id_fkey` (`tahun_ajaran_id`),
  CONSTRAINT `riwayat_pendidikan_orang_id_fkey` FOREIGN KEY (`orang_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `riwayat_pendidikan_tahun_ajaran_id_fkey` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `riwayat_pendidikan_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riwayat_pendidikan`
--

LOCK TABLES `riwayat_pendidikan` WRITE;
/*!40000 ALTER TABLE `riwayat_pendidikan` DISABLE KEYS */;
/*!40000 ALTER TABLE `riwayat_pendidikan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `santri`
--

DROP TABLE IF EXISTS `santri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `santri` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `orang_id` bigint NOT NULL,
  `nis` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nisn` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `kelas_id` int DEFAULT NULL,
  `kamar_id` int DEFAULT NULL,
  `status` enum('Mukim','Alumni','Keluar') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Mukim',
  `program` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun_masuk` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `santri_orang_id_key` (`orang_id`),
  UNIQUE KEY `santri_nis_key` (`nis`),
  UNIQUE KEY `santri_nisn_key` (`nisn`),
  KEY `santri_status_idx` (`status`),
  KEY `santri_unit_id_fkey` (`unit_id`),
  KEY `santri_kelas_id_fkey` (`kelas_id`),
  KEY `santri_kamar_id_fkey` (`kamar_id`),
  CONSTRAINT `santri_kamar_id_fkey` FOREIGN KEY (`kamar_id`) REFERENCES `kamar` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `santri_kelas_id_fkey` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `santri_orang_id_fkey` FOREIGN KEY (`orang_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `santri_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `santri`
--

LOCK TABLES `santri` WRITE;
/*!40000 ALTER TABLE `santri` DISABLE KEYS */;
/*!40000 ALTER TABLE `santri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `santri_kelas`
--

DROP TABLE IF EXISTS `santri_kelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `santri_kelas` (
  `santri_id` bigint NOT NULL,
  `kelas_id` int NOT NULL,
  `unit_id` int NOT NULL,
  `utama` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`santri_id`,`kelas_id`),
  KEY `santri_kelas_kelas_id_idx` (`kelas_id`),
  KEY `santri_kelas_unit_id_idx` (`unit_id`),
  CONSTRAINT `santri_kelas_kelas_id_fkey` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `santri_kelas_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `santri_kelas_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `santri_kelas`
--

LOCK TABLES `santri_kelas` WRITE;
/*!40000 ALTER TABLE `santri_kelas` DISABLE KEYS */;
/*!40000 ALTER TABLE `santri_kelas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesi_cbt`
--

DROP TABLE IF EXISTS `sesi_cbt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesi_cbt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paket_id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `jadwal_id` int DEFAULT NULL,
  `mulai` datetime(3) NOT NULL,
  `selesai` datetime(3) NOT NULL,
  `token` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_prefix` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wajib_exam_browser` tinyint(1) NOT NULL DEFAULT '0',
  `batas_pelanggaran` int NOT NULL DEFAULT '3',
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Terjadwal',
  `pengawas` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `sesi_cbt_kode_key` (`kode`),
  KEY `sesi_cbt_status_idx` (`status`),
  KEY `sesi_cbt_paket_id_fkey` (`paket_id`),
  KEY `sesi_cbt_kelas_id_fkey` (`kelas_id`),
  KEY `sesi_cbt_jadwal_id_fkey` (`jadwal_id`),
  CONSTRAINT `sesi_cbt_jadwal_id_fkey` FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_ujian` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sesi_cbt_kelas_id_fkey` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `sesi_cbt_paket_id_fkey` FOREIGN KEY (`paket_id`) REFERENCES `paket_soal` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesi_cbt`
--

LOCK TABLES `sesi_cbt` WRITE;
/*!40000 ALTER TABLE `sesi_cbt` DISABLE KEYS */;
/*!40000 ALTER TABLE `sesi_cbt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slip_gaji`
--

DROP TABLE IF EXISTS `slip_gaji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slip_gaji` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pegawai_id` bigint NOT NULL,
  `periode` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bruto` decimal(14,2) NOT NULL,
  `potongan` decimal(14,2) NOT NULL,
  `netto` decimal(14,2) NOT NULL,
  `dibayar_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `catatan_revisi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diterbitkan_oleh` bigint DEFAULT NULL,
  `revisi` int NOT NULL DEFAULT '0',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draft',
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slip_gaji_pegawai_id_periode_key` (`pegawai_id`,`periode`),
  CONSTRAINT `slip_gaji_pegawai_id_fkey` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slip_gaji`
--

LOCK TABLES `slip_gaji` WRITE;
/*!40000 ALTER TABLE `slip_gaji` DISABLE KEYS */;
/*!40000 ALTER TABLE `slip_gaji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `soal`
--

DROP TABLE IF EXISTS `soal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `soal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mapel_id` int NOT NULL,
  `penulis` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` enum('PG','PGK','BS','Menjodohkan','IsianSingkat','Esai') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PG',
  `level` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C1',
  `topik` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stimulus` text COLLATE utf8mb4_unicode_ci,
  `pertanyaan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `kunci` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pembahasan` text COLLATE utf8mb4_unicode_ci,
  `bobot` decimal(6,2) NOT NULL DEFAULT '1.00',
  `irt_a` decimal(6,3) DEFAULT NULL,
  `irt_b` decimal(6,3) DEFAULT NULL,
  `irt_c` decimal(6,3) DEFAULT NULL,
  `p_diff` decimal(6,3) DEFAULT NULL,
  `d_index` decimal(6,3) DEFAULT NULL,
  `dipakai` int NOT NULL DEFAULT '0',
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `soal_mapel_id_tipe_idx` (`mapel_id`,`tipe`),
  KEY `soal_aktif_idx` (`aktif`),
  CONSTRAINT `soal_mapel_id_fkey` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `soal`
--

LOCK TABLES `soal` WRITE;
/*!40000 ALTER TABLE `soal` DISABLE KEYS */;
/*!40000 ALTER TABLE `soal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagihan`
--

DROP TABLE IF EXISTS `tagihan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagihan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `santri_id` bigint NOT NULL,
  `jenis` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `periode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `dibayar` decimal(14,2) NOT NULL DEFAULT '0.00',
  `jatuh_tempo` date NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tagihan_kode_key` (`kode`),
  KEY `tagihan_periode_idx` (`periode`),
  KEY `tagihan_santri_id_fkey` (`santri_id`),
  CONSTRAINT `tagihan_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagihan`
--

LOCK TABLES `tagihan` WRITE;
/*!40000 ALTER TABLE `tagihan` DISABLE KEYS */;
/*!40000 ALTER TABLE `tagihan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tahun_ajaran`
--

DROP TABLE IF EXISTS `tahun_ajaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tahun_ajaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(16) NOT NULL,
  `semester` varchar(8) NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tahun_ajaran_kode_semester_key` (`kode`,`semester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tahun_ajaran`
--

LOCK TABLES `tahun_ajaran` WRITE;
/*!40000 ALTER TABLE `tahun_ajaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `tahun_ajaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tazir`
--

DROP TABLE IF EXISTS `tazir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tazir` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `santri_id` bigint NOT NULL,
  `tgl` date NOT NULL,
  `pelanggaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poin` int NOT NULL DEFAULT '0',
  `sanksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `petugas` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tazir_santri_id_tgl_idx` (`santri_id`,`tgl`),
  CONSTRAINT `tazir_santri_id_fkey` FOREIGN KEY (`santri_id`) REFERENCES `santri` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tazir`
--

LOCK TABLES `tazir` WRITE;
/*!40000 ALTER TABLE `tazir` DISABLE KEYS */;
/*!40000 ALTER TABLE `tazir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_wa`
--

DROP TABLE IF EXISTS `template_wa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_wa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pemicu` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `waktu` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_wa_kode_key` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_wa`
--

LOCK TABLES `template_wa` WRITE;
/*!40000 ALTER TABLE `template_wa` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_wa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi_kas`
--

DROP TABLE IF EXISTS `transaksi_kas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_kas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl` date NOT NULL,
  `uraian` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metode` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arah` enum('Masuk','Keluar') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaksi_kas_kode_key` (`kode`),
  KEY `transaksi_kas_tgl_idx` (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_kas`
--

LOCK TABLES `transaksi_kas` WRITE;
/*!40000 ALTER TABLE `transaksi_kas` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaksi_kas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tugas_lms`
--

DROP TABLE IF EXISTS `tugas_lms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tugas_lms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kursus_id` int NOT NULL,
  `judul` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deadline` datetime NOT NULL,
  `status` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tugas_lms_kode_key` (`kode`),
  KEY `tugas_lms_kursus_id_fkey` (`kursus_id`),
  CONSTRAINT `tugas_lms_kursus_id_fkey` FOREIGN KEY (`kursus_id`) REFERENCES `kursus_lms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tugas_lms`
--

LOCK TABLES `tugas_lms` WRITE;
/*!40000 ALTER TABLE `tugas_lms` DISABLE KEYS */;
/*!40000 ALTER TABLE `tugas_lms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ujian`
--

DROP TABLE IF EXISTS `ujian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ujian` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_id` int NOT NULL,
  `tahun_ajaran` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mulai` date NOT NULL,
  `selesai` date NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draf',
  `catatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ujian_kode_key` (`kode`),
  KEY `ujian_status_idx` (`status`),
  KEY `ujian_unit_id_fkey` (`unit_id`),
  CONSTRAINT `ujian_unit_id_fkey` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ujian`
--

LOCK TABLES `ujian` WRITE;
/*!40000 ALTER TABLE `ujian` DISABLE KEYS */;
/*!40000 ALTER TABLE `ujian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `nama_resmi` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenjang` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `npsn` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `akreditasi` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun_berdiri` int DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telepon` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala_nama` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala_jabatan` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala_pegawai_id` bigint DEFAULT NULL,
  `visi` text COLLATE utf8mb4_unicode_ci,
  `misi` text COLLATE utf8mb4_unicode_ci,
  `desa_id` bigint DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_key_key` (`key`),
  KEY `unit_kepala_pegawai_id_idx` (`kepala_pegawai_id`),
  KEY `unit_desa_id_idx` (`desa_id`),
  CONSTRAINT `unit_desa_id_fkey` FOREIGN KEY (`desa_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `unit_kepala_pegawai_id_fkey` FOREIGN KEY (`kepala_pegawai_id`) REFERENCES `pegawai` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `orang_id` bigint NOT NULL,
  `email` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_scope` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_orang_id_key` (`orang_id`),
  UNIQUE KEY `user_email_key` (`email`),
  UNIQUE KEY `user_username_key` (`username`),
  CONSTRAINT `user_orang_id_fkey` FOREIGN KEY (`orang_id`) REFERENCES `orang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_peran`
--

DROP TABLE IF EXISTS `user_peran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_peran` (
  `user_id` bigint NOT NULL,
  `peran_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`peran_id`),
  KEY `user_peran_peran_id_fkey` (`peran_id`),
  CONSTRAINT `user_peran_peran_id_fkey` FOREIGN KEY (`peran_id`) REFERENCES `peran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_peran_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_peran`
--

LOCK TABLES `user_peran` WRITE;
/*!40000 ALTER TABLE `user_peran` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_peran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nuha_shadow'
--

--
-- Dumping routines for database 'nuha_shadow'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-07  5:44:14
