﻿Imports System.Web
Imports System.Web.Services
'Imports System.Web.Services.Protocols
'Imports System.Web.Script.Services
Imports System.Data
Imports AsModuleMySQL.CommonFunction
Imports System.Globalization

'<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class m2_giro_list
    Inherits System.Web.Services.WebService
    Public ClsValidKey As New ClsSecurity
    Dim userid As String = ""     'User Id diisi dengan user yang melakukan proses transaksi

    <WebMethod()>
    Public Function M2_Giro_ListSearch(ByVal param As String) As String
        'M2_Giro_ListSearch --------------------------------------------------------
        'glnogiro, glsumber, glidtransaksi, glnotransaksi, glkontak, glrekbank, glrekgiro, 
        'gljenis, glbank, glnoacbank, glmatauang, glkurs, gljumlah, gljumlahvalas, 
        'gltgljthtempo, gltglcair, glstatus, glstatussebelumnya, glurutan, glkontakkode, glkontaknama, 
        'glrekbanknama, glrekgironama, gljenisnama, glbanknama, glstatusnama, glstatussebelumnyanama, gltgltransaksi

        On Error GoTo selesai
        Dim formatTgl As String = "", formatTglWaktu As String = "", search As String = ""

        Dim paramSplit(6) As String     'WebsiteAccessKey(0), paket(1), paging(2), userid(3), isUpdate(4), data(5)
        Dim pagingSplit(6) As String    'pageNumber(0), itemLimit(1), strFilter(2), strSort(3), formatTgl(4), formatTglWaktu(5)

        Dim result(5) As String         'target(0), success(1), errmessage(2), errstep(3), idtransaksi(4)
        Dim resultPaging(5) As String   'ispaging(0), isNext(1), isPrev(2), countPage(3), countRow(4)

        Dim wsResult As String = ""
        Dim strResult, strResultPaging As String

        Dim sql As String = ""

        Dim pg1 As New RsPaging
        Dim Filter As String = "", Sorting As String = ""
        Dim dt As New DataTable

        'SET DEFAULT 
        result(0) = System.Reflection.MethodBase.GetCurrentMethod.Name 'Mengambil nama method
        result(1) = 0 : result(2) = "" : result(3) = 0 : result(4) = 0

        'SET DEFAULT PAGING
        resultPaging(0) = 0 : resultPaging(1) = 0 : resultPaging(2) = 0 : resultPaging(3) = 0 : resultPaging(4) = 0

        'VALIDASI PARAMETER GLOBAL =========================================================
        'SPLIT PARAM
        paramSplit = param.Split(sptParam)

        'CEK ARRAY PARAM
        If (paramSplit.Length <> 6) Then
            result(2) = "Invalid parameter." : GoTo selesai
        End If
        'END OF VALIDASI PARAMETER GLOBAL ==================================================

        'VALIDASI WEBSITEACCESSKEY =========================================================
        If Len(paramSplit(0)) = 0 Then
            result(2) = "WebsiteAccessKey can't be empty." : GoTo selesai
        End If

        'Cek apakah WebsiteAccessKey valid
        Dim ClsValidKey As New ClsSecurity
        Dim validKey As RsValidKey
        validKey = ValidateKey(paramSplit(0))
        If Not validKey.success Then result(2) = validKey.errmessage : GoTo selesai

        '///Validasi Hak akses. Cek ModuleID dan MenuID
        If ClsValidKey.ApaBisaAkses(1, 1, 3) = False Then
            result(2) = "Access denied for get data"
        End If
        'END OF VALIDASI WEBSITEACCESSKEY ==================================================

        'VALIDASI PARAMETER PAGING =========================================================
        'SPLIT PARAMETER PAGING
        pagingSplit = paramSplit(2).Split(sptSubParam)

        'CEK ARRAY PAGING
        If (pagingSplit.Length <> 6) Then
            result(2) = "Invalid paging parameter." : GoTo selesai
        End If

        'CEK PAGENUMBER
        If (IsNumeric(pagingSplit(0)) = False) Then
            result(2) = "pageNumber required numeric." : GoTo selesai
        End If

        'CEK ITEMLIMIT
        If (IsNumeric(pagingSplit(1)) = False) Then
            result(2) = "itemLimit required numeric." : GoTo selesai
        End If

        'CEK FORMATTGL
        If Len(pagingSplit(4)) = 0 Then
            formatTgl = "yyyy-MM-dd"
        Else
            formatTgl = pagingSplit(4)
        End If

        'CEK FORMATTGLWAKTU
        If Len(pagingSplit(5)) = 0 Then
            formatTglWaktu = "yyyy-MM-dd H:mm:ss"
        Else
            formatTglWaktu = pagingSplit(5)
        End If
        'END OF VALIDASI PARAMETER PAGING ==================================================

        'Replace disesuaikan dengan kebutuhan
        If (pagingSplit(2).Length > 0) Then
            Filter = pagingSplit(2)
            Filter = Filter.Replace("glkontakkode", "c.kkode")
            Filter = Filter.Replace("glkontaknama", "c.knama")
            Filter = Filter.Replace("glrekbanknama", "coa1.cnama")
            Filter = Filter.Replace("gltgltransaksi", "t.ttgl")
            '#Taruh fungsi replace disini...
        End If
        If (pagingSplit(3).Length > 0) Then
            Sorting = pagingSplit(3)
            '#Taruh fungsi replace disini...
        End If

        'PANGGIL QUERY
        Dim query As New m0_query
        sql = query.PanggilQuery("m2_giro_list_v")

        'BUKA KONEKSI
        Con1 = New MySql.Data.MySqlClient.MySqlConnection(Application("As_ConStr1"))
        Con1.Open()

        dt = AmbilData("aplikasi1-m2_giro_list_v", Filter, Sorting, True, , , pagingSplit(0), pagingSplit(1), pg1, , , "gl.glnogiro", sql) ' Ambil data ke databases
        pg1 = pg1
        If dt.Rows.Count > 0 Then
            For Each dr As DataRow In dt.Rows
                search = String.Concat(search,
                     FxDB(dr("glnogiro"), ""), sptField,
                     FxDB(dr("glsumber"), ""), sptField,
                     FxDB(dr("glidtransaksi"), 0), sptField,
                     FxDB(dr("glnotransaksi"), ""), sptField,
                     FxDB(dr("glkontak"), 0), sptField,
                     FxDB(dr("glrekbank"), ""), sptField,
                     FxDB(dr("glrekgiro"), ""), sptField,
                     FxDB(dr("gljenis"), 0), sptField,
                     FxDB(dr("glbank"), ""), sptField,
                     FxDB(dr("glnoacbank"), ""), sptField,
                     FxDB(dr("glmatauang"), ""), sptField,
                     FxDB(dr("glkurs"), 0), sptField,
                     FxDB(dr("gljumlah"), 0), sptField,
                     FxDB(dr("gljumlahvalas"), 0), sptField,
                     AsFormatTanggal(FxDB(dr("gltgljthtempo"), ""), formatTgl), sptField,
                     AsFormatTanggal(FxDB(dr("gltglcair"), ""), formatTgl), sptField,
                     FxDB(dr("glstatus"), 0), sptField,
                     FxDB(dr("glstatussebelumnya"), 0), sptField,
                     FxDB(dr("glurutan"), 0), sptField,
                     FxDB(dr("glkontakkode"), ""), sptField,
                     FxDB(dr("glkontaknama"), ""), sptField,
                     FxDB(dr("glrekbanknama"), ""), sptField,
                     FxDB(dr("glrekgironama"), ""), sptField,
                     FxDB(dr("gljenisnama"), ""), sptField,
                     FxDB(dr("glbanknama"), ""), sptField,
                     FxDB(dr("glstatusnama"), ""), sptField,
                     FxDB(dr("glstatussebelumnyanama"), ""), sptField,
                     AsFormatTanggal(FxDB(dr("gltgltransaksi"), ""), formatTgl), sptRow)
            Next
            search = search.Substring(0, search.Length - sptRow.Length)

            result(1) = 1
            resultPaging(0) = Math.Abs(Val(pg1.isPaging))
            resultPaging(1) = Math.Abs(Val(pg1.isNext))
            resultPaging(2) = Math.Abs(Val(pg1.isPrev))
            resultPaging(3) = pg1.countPage
            resultPaging(4) = pg1.countRow
        Else
            result(2) = "Giro data not found."
        End If

selesai:
        If result(1) = 0 Then
            If Len(result(2)) = 0 Then result(2) = "Nomor : " & Err.Number & ". Sumber : " & Err.Source & ".  Fungsi : " & System.Reflection.MethodBase.GetCurrentMethod.Name & ". Uraian : " & Err.Description & ". "
        End If

        strResult = String.Join(sptSubParam, result)
        strResultPaging = String.Join(sptSubParam, resultPaging)
        wsResult = String.Concat(strResult.Substring(0, strResult.Length - 1), sptParam, strResultPaging.Substring(0, strResultPaging.Length - 1), sptParam, search)

        wsResult = String.Concat(wsResult, sptParam, ReplaceMapping("glnogiro, glsumber, glidtransaksi, glnotransaksi, glkontak, glrekbank, glrekgiro, gljenis, glbank, glnoacbank, glmatauang, glkurs, gljumlah, gljumlahvalas, gltgljthtempo, gltglcair, glstatus, glstatussebelumnya, glurutan, glkontakkode, glkontaknama, glrekbanknama, glrekgironama, gljenisnama, glbanknama, glstatusnama, glstatussebelumnyanama, gltgltransaksi"))

        Return wsResult
    End Function

End Class